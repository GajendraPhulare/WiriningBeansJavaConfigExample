package WiringBeans2.Test2;



public interface CompactDisc {
void play();
}
