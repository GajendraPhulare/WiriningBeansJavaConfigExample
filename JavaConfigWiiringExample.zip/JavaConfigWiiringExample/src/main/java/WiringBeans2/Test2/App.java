package WiringBeans2.Test2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext applicationContext=new AnnotationConfigApplicationContext(CompConfig.class);
      CDPlayer cdPlayer=applicationContext.getBean(SonyCDPlayer.class);
      cdPlayer.startPlayer();
    
    }
}
