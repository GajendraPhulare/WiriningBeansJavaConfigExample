package WiringBeans2.Test2;

public class SonyCDPlayer implements CDPlayer {

	private CompactDisc cd;
	
	public SonyCDPlayer() {
		// TODO Auto-generated constructor stub
	}
	
	public SonyCDPlayer(CompactDisc cd) {
		// TODO Auto-generated constructor stub
		this.cd=cd;
	}
	
	
	public void startPlayer() {
		// TODO Auto-generated method stub
System.out.println("CD Plyer Started...");
cd.play();
	}

}
