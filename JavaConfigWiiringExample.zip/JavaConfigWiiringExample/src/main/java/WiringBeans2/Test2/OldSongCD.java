package WiringBeans2.Test2;

public class OldSongCD implements CompactDisc {

	public void play() {
		// TODO Auto-generated method stub
System.out.println("Playing old hind song 1....");
	}

}
