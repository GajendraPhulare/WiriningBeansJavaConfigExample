package WiringBeans2.Test2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CompConfig {

	@Bean
	public CompactDisc getCompactDisc() {
		
		return new OldSongCD();
	}
	
	@Bean
	public CDPlayer getCdPlayer() {
		
		return new SonyCDPlayer(getCompactDisc());
	}
	

}
